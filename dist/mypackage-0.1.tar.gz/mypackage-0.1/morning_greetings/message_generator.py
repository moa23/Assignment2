def generate_message(name):
    return f"Good morning, {name}! Have a great day!"

